# Helvite

|  |  |
| --- | --- |
| Helvite | |
| [Helvite.png](/File:Helvite.png) | |
| It grows in a triangular column. | |
| Information | |
| Source | Magma Geode.png [Magma Geode](/Magma_Geode "Magma Geode")Omni Geode.png [Omni Geode](/Omni_Geode "Omni Geode") |
| Sell Price | data-sort-value="450 ">Gold.png450g |
| Gemologist.png Gemologist Profession *(+30% Sell Price)* | data-sort-value="585 ">Gold.png585g |

**Helvite** is a [mineral](/Minerals#Geode_Minerals "Minerals") that can be found in the [Magma Geode](/Magma_Geode "Magma Geode") and the [Omni Geode](/Omni_Geode "Omni Geode").

## Gifting

| Villager Reactions | |
| --- | --- |
| Like | [Wizard Icon.png](/Wizard "Wizard") [Wizard](/Wizard "Wizard") |
| Dislike | [Abigail Icon.png](/Abigail "Abigail") [Abigail](/Abigail "Abigail") • [Alex Icon.png](/Alex "Alex") [Alex](/Alex "Alex") • [Caroline Icon.png](/Caroline "Caroline") [Caroline](/Caroline "Caroline") • [Clint Icon.png](/Clint "Clint") [Clint](/Clint "Clint") • [Demetrius Icon.png](/Demetrius "Demetrius") [Demetrius](/Demetrius "Demetrius") • [Dwarf Icon.png](/Dwarf "Dwarf") [Dwarf](/Dwarf "Dwarf") • [Elliott Icon.png](/Elliott "Elliott") [Elliott](/Elliott "Elliott") • [Emily Icon.png](/Emily "Emily") [Emily](/Emily "Emily") • [Evelyn Icon.png](/Evelyn "Evelyn") [Evelyn](/Evelyn "Evelyn") • [George Icon.png](/George "George") [George](/George "George") • [Gus Icon.png](/Gus "Gus") [Gus](/Gus "Gus") • [Haley Icon.png](/Haley "Haley") [Haley](/Haley "Haley") • [Harvey Icon.png](/Harvey "Harvey") [Harvey](/Harvey "Harvey") • [Jas Icon.png](/Jas "Jas") [Jas](/Jas "Jas") • [Jodi Icon.png](/Jodi "Jodi") [Jodi](/Jodi "Jodi") • [Kent Icon.png](/Kent "Kent") [Kent](/Kent "Kent") • [Krobus Icon.png](/Krobus "Krobus") [Krobus](/Krobus "Krobus") • [Leah Icon.png](/Leah "Leah") [Leah](/Leah "Leah") • [Leo Icon.png](/Leo "Leo") [Leo](/Leo "Leo") • [Lewis Icon.png](/Lewis "Lewis") [Lewis](/Lewis "Lewis") • [Linus Icon.png](/Linus "Linus") [Linus](/Linus "Linus") • [Marnie Icon.png](/Marnie "Marnie") [Marnie](/Marnie "Marnie") • [Maru Icon.png](/Maru "Maru") [Maru](/Maru "Maru") • [Pam Icon.png](/Pam "Pam") [Pam](/Pam "Pam") • [Penny Icon.png](/Penny "Penny") [Penny](/Penny "Penny") • [Pierre Icon.png](/Pierre "Pierre") [Pierre](/Pierre "Pierre") • [Robin Icon.png](/Robin "Robin") [Robin](/Robin "Robin") • [Sam Icon.png](/Sam "Sam") [Sam](/Sam "Sam") • [Sandy Icon.png](/Sandy "Sandy") [Sandy](/Sandy "Sandy") • [Sebastian Icon.png](/Sebastian "Sebastian") [Sebastian](/Sebastian "Sebastian") • [Shane Icon.png](/Shane "Shane") [Shane](/Shane "Shane") • [Vincent Icon.png](/Vincent "Vincent") [Vincent](/Vincent "Vincent") • [Willy Icon.png](/Willy "Willy") [Willy](/Willy "Willy") |

## Bundles

Helvite is not used in any [bundles](/Bundles "Bundles").

## Recipes

Helvite is not used in any [recipes](/Cooking "Cooking").

## Tailoring

Helvite is used in the spool of the [Sewing Machine](/2_Willow_Lane#Sewing_Machine "2 Willow Lane") to create the [Classy Top](/Tailoring "Tailoring").

* Male version: [![Shirt201.png](/mediawiki/images/thumb/f/f2/Shirt201.png/24px-Shirt201.png)](/File:Shirt201.png)
* Female version: [![Shirt202.png](/mediawiki/images/thumb/9/94/Shirt202.png/24px-Shirt202.png)](/File:Shirt202.png)

It can also be used as a red dye color at the dye pots in [Emily](/Emily "Emily")'s and [Haley](/Haley "Haley")'s house, located at [2 Willow Lane](/2_Willow_Lane "2 Willow Lane").

## Quests

Helvite is not used in any [quests](/Quests "Quests").

## History

* [1.4](/Version_History#1.4 "Version History"): Can now be used in [Tailoring](/Tailoring "Tailoring").

| [Minerals](/Minerals "Minerals") | |
| --- | --- |
| [Foraged Minerals](/Minerals#Foraged_Minerals "Minerals") | [Earth Crystal](/Earth_Crystal "Earth Crystal") • [Fire Quartz](/Fire_Quartz "Fire Quartz") • [Frozen Tear](/Frozen_Tear "Frozen Tear") • [Quartz](/Quartz "Quartz") |
| [Gems](/Minerals#Gems "Minerals") | [Amethyst](/Amethyst "Amethyst") • [Aquamarine](/Aquamarine "Aquamarine") • [Diamond](/Diamond "Diamond") • [Emerald](/Emerald "Emerald") • [Jade](/Jade "Jade") • [Prismatic Shard](/Prismatic_Shard "Prismatic Shard") • [Ruby](/Ruby "Ruby") • [Topaz](/Topaz "Topaz") |
| [Geode Minerals](/Minerals#Geode_Minerals "Minerals") | [Aerinite](/Aerinite "Aerinite") • [Alamite](/Alamite "Alamite") • [Baryte](/Baryte "Baryte") • [Basalt](/Basalt "Basalt") • [Bixite](/Bixite "Bixite") • [Calcite](/Calcite "Calcite") • [Celestine](/Celestine "Celestine") • [Dolomite](/Dolomite "Dolomite") • [Esperite](/Esperite "Esperite") • [Fairy Stone](/Fairy_Stone "Fairy Stone") • [Fire Opal](/Fire_Opal "Fire Opal") • [Fluorapatite](/Fluorapatite "Fluorapatite") • [Geminite](/Geminite "Geminite") • [Ghost Crystal](/Ghost_Crystal "Ghost Crystal") • [Granite](/Granite "Granite") • Helvite • [Hematite](/Hematite "Hematite") • [Jagoite](/Jagoite "Jagoite") • [Jamborite](/Jamborite "Jamborite") • [Jasper](/Jasper "Jasper") • [Kyanite](/Kyanite "Kyanite") • [Lemon Stone](/Lemon_Stone "Lemon Stone") • [Limestone](/Limestone "Limestone") • [Lunarite](/Lunarite "Lunarite") • [Malachite](/Malachite "Malachite") • [Marble](/Marble "Marble") • [Mudstone](/Mudstone "Mudstone") • [Nekoite](/Nekoite "Nekoite") • [Neptunite](/Neptunite "Neptunite") • [Obsidian](/Obsidian "Obsidian") • [Ocean Stone](/Ocean_Stone "Ocean Stone") • [Opal](/Opal "Opal") • [Orpiment](/Orpiment "Orpiment") • [Petrified Slime](/Petrified_Slime "Petrified Slime") • [Pyrite](/Pyrite "Pyrite") • [Sandstone](/Sandstone "Sandstone") • [Slate](/Slate "Slate") • [Soapstone](/Soapstone "Soapstone") • [Star Shards](/Star_Shards "Star Shards") • [Thunder Egg](/Thunder_Egg "Thunder Egg") • [Tigerseye](/Tigerseye "Tigerseye") |
| [Geodes](/Minerals#Geodes "Minerals") | [Geode](/Geode "Geode") • [Frozen Geode](/Frozen_Geode "Frozen Geode") • [Magma Geode](/Magma_Geode "Magma Geode") • [Omni Geode](/Omni_Geode "Omni Geode") |