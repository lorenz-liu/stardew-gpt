# Copper Hoe

Redirect to:

* [Hoes](/Hoes "Hoes")