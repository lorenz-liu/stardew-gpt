# Galaxy Hammer

|  |  |
| --- | --- |
| Galaxy Hammer | |
| [Galaxy Hammer.png](/File:Galaxy_Hammer.png) | |
| It's made from an ultra-light material you've never seen before. | |
| Information | |
| Type: | Club |
| Level: | 12 |
| Source: | [Adventurer's Guild](/Adventurer%27s_Guild "Adventurer's Guild") |
| Damage: | 70-90 |
| Critical Strike Chance: | .02 |
| Stats: | Speed w.png [Speed](/Speed "Speed") (+2)Weight.png [Weight](/Weight "Weight") (+5) |
| Adventurer's Guild | |
| Purchase Price: | data-sort-value="75000 ">Gold.png75,000g |
| Sell Price: | data-sort-value="600 ">Gold.png600g |

The **Galaxy Hammer** is a [club weapon](/Weapons#Club "Weapons") that can be purchased for data-sort-value="75000">![Gold.png](/mediawiki/images/thumb/1/10/Gold.png/18px-Gold.png)75,000g at the [Adventurer's Guild](/Adventurer%27s_Guild "Adventurer's Guild") after obtaining a [Galaxy Sword](/Galaxy_Sword "Galaxy Sword").

It can be combined with ![Galaxy Soul.png](/mediawiki/images/thumb/1/17/Galaxy_Soul.png/24px-Galaxy_Soul.png) [Galaxy Soul](/Galaxy_Soul "Galaxy Soul") (3) and ![Cinder Shard.png](/mediawiki/images/thumb/f/fd/Cinder_Shard.png/24px-Cinder_Shard.png) [Cinder Shard](/Cinder_Shard "Cinder Shard") (60) in the [Forge](/Forge "Forge") to create the ![Infinity Gavel.png](/mediawiki/images/thumb/8/87/Infinity_Gavel.png/24px-Infinity_Gavel.png) [Infinity Gavel](/Infinity_Gavel "Infinity Gavel").

## History

* [1.1](/Version_History#1.1 "Version History"): Introduced.
* [1.4](/Version_History#1.4 "Version History"): Description changed from "It's made from an ultra-light material you've seen before."
* [1.5](/Version_History#1.5 "Version History"): Can now be changed into an Infinity Gavel. Level increased from 9 to 12, sell price increased from data-sort-value="450">![Gold.png](/mediawiki/images/thumb/1/10/Gold.png/18px-Gold.png)450g to data-sort-value="600">![Gold.png](/mediawiki/images/thumb/1/10/Gold.png/18px-Gold.png)600g.

| [Weapons](/Weapons "Weapons") | |
| --- | --- |
| [Swords](/Weapons#Sword "Weapons") | [Bone Sword](/Bone_Sword "Bone Sword") • [Claymore](/Claymore "Claymore") • [Cutlass](/Cutlass "Cutlass") • [Dark Sword](/Dark_Sword "Dark Sword") • [Dragontooth Cutlass](/Dragontooth_Cutlass "Dragontooth Cutlass") • [Dwarf Sword](/Dwarf_Sword "Dwarf Sword") • [Forest Sword](/Forest_Sword "Forest Sword") • [Galaxy Sword](/Galaxy_Sword "Galaxy Sword") • [Haley's Iron](/Haley%27s_Iron "Haley's Iron") • [Holy Blade](/Holy_Blade "Holy Blade") • [Infinity Blade](/Infinity_Blade "Infinity Blade") • [Insect Head](/Insect_Head "Insect Head") • [Iron Edge](/Iron_Edge "Iron Edge") • [Lava Katana](/Lava_Katana "Lava Katana") • [Leah's Whittler](/Leah%27s_Whittler "Leah's Whittler") • [Meowmere](/Meowmere "Meowmere") • [Neptune's Glaive](/Neptune%27s_Glaive "Neptune's Glaive") • [Obsidian Edge](/Obsidian_Edge "Obsidian Edge") • [Ossified Blade](/Ossified_Blade "Ossified Blade") • [Pirate's Sword](/Pirate%27s_Sword "Pirate's Sword") • [Rusty Sword](/Rusty_Sword "Rusty Sword") • [Silver Saber](/Silver_Saber "Silver Saber") • [Steel Falchion](/Steel_Falchion "Steel Falchion") • [Steel Smallsword](/Steel_Smallsword "Steel Smallsword") • [Tempered Broadsword](/Tempered_Broadsword "Tempered Broadsword") • [Templar's Blade](/Templar%27s_Blade "Templar's Blade") • [Wooden Blade](/Wooden_Blade "Wooden Blade") • [Yeti Tooth](/Yeti_Tooth "Yeti Tooth") |
| [Daggers](/Weapons#Dagger "Weapons") | [Abby's Planchette](/Abby%27s_Planchette "Abby's Planchette") • [Broken Trident](/Broken_Trident "Broken Trident") • [Burglar's Shank](/Burglar%27s_Shank "Burglar's Shank") • [Carving Knife](/Carving_Knife "Carving Knife") • [Crystal Dagger](/Crystal_Dagger "Crystal Dagger") • [Dragontooth Shiv](/Dragontooth_Shiv "Dragontooth Shiv") • [Dwarf Dagger](/Dwarf_Dagger "Dwarf Dagger") • [Elf Blade](/Elf_Blade "Elf Blade") • [Elliott's Pencil](/Elliott%27s_Pencil "Elliott's Pencil") • [Galaxy Dagger](/Galaxy_Dagger "Galaxy Dagger") • [Infinity Dagger](/Infinity_Dagger "Infinity Dagger") • [Iridium Needle](/Iridium_Needle "Iridium Needle") • [Iron Dirk](/Iron_Dirk "Iron Dirk") • [Shadow Dagger](/Shadow_Dagger "Shadow Dagger") • [Wicked Kris](/Wicked_Kris "Wicked Kris") • [Wind Spire](/Wind_Spire "Wind Spire") |
| [Clubs](/Weapons#Club "Weapons") | [Alex's Bat](/Alex%27s_Bat "Alex's Bat") • [Dragontooth Club](/Dragontooth_Club "Dragontooth Club") • [Dwarf Hammer](/Dwarf_Hammer "Dwarf Hammer") • [Femur](/Femur "Femur") • Galaxy Hammer • [Harvey's Mallet](/Harvey%27s_Mallet "Harvey's Mallet") • [Infinity Gavel](/Infinity_Gavel "Infinity Gavel") • [Kudgel](/Kudgel "Kudgel") • [Lead Rod](/Lead_Rod "Lead Rod") • [Maru's Wrench](/Maru%27s_Wrench "Maru's Wrench") • [Penny's Fryer](/Penny%27s_Fryer "Penny's Fryer") • [Seb's Lost Mace](/Seb%27s_Lost_Mace "Seb's Lost Mace") • [Sam's Old Guitar](/Sam%27s_Old_Guitar "Sam's Old Guitar") • [The Slammer](/The_Slammer "The Slammer") • [Wood Club](/Wood_Club "Wood Club") • [Wood Mallet](/Wood_Mallet "Wood Mallet") |
| [Slingshots](/Weapons#Slingshot "Weapons") | [Slingshot](/Slingshot "Slingshot") • [Master Slingshot](/Master_Slingshot "Master Slingshot") • [Explosive Ammo](/Explosive_Ammo "Explosive Ammo") |
| [Unobtainable Weapons](/Weapons#Unobtainable_Weapons "Weapons") | [Galaxy Slingshot](/Galaxy_Slingshot "Galaxy Slingshot") • [Rapier](/Rapier "Rapier") |