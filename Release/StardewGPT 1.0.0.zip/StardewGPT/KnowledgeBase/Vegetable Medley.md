# Vegetable Medley

|  |  |
| --- | --- |
| Vegetable Medley | |
| [Vegetable Medley.png](/File:Vegetable_Medley.png) | |
| This is very nutritious. | |
| Information | |
| Source | [Cooking](/Cooking "Cooking") |
| [Energy](/Energy "Energy") / [Health](/Health "Health") | |  |  |  |  | | --- | --- | --- | --- | | Energy.png | 165 | Health.png | 74 | |
| Sell Price | |  |  | | --- | --- | | Vegetable Medley.png | 120g | |
| Qi Seasoning.png[Qi Seasoning](/Qi_Seasoning "Qi Seasoning") | |  |  |  |  |  |  |  |  |  | | --- | --- | --- | --- | --- | --- | --- | --- | --- | | |  |  |  |  | | --- | --- | --- | --- | | Energy.png  Gold Quality Icon.png | 297 | Health.png  Gold Quality Icon.png | 133 | |  | |  |  | | --- | --- | | Vegetable Medley.png  Gold Quality Icon.png | 180g | | |
| Recipe | |
| Recipe Source(s) | Caroline Icon.png [Caroline](/Caroline "Caroline") (Mail - 7+ HeartIconLarge.png) |
| Ingredients | Tomato.png [Tomato](/Tomato "Tomato") (1)Beet.png [Beet](/Beet "Beet") (1) |

**Vegetable Medley** (also called "**Vegetable Stew**" in the Cooking interface) is a [cooked dish](/Cooking "Cooking"). It is prepared using either the kitchen inside an upgraded [farmhouse](/Farmhouse "Farmhouse") or a [Cookout Kit](/Cookout_Kit "Cookout Kit").

Vegetable Medley may randomly appear in [Krobus](/Krobus "Krobus")' shop on [Saturdays](/Days_of_the_Week#Saturday "Days of the Week"), in the [Garbage Can](/Garbage_Can "Garbage Can") outside the saloon, or in [the Stardrop Saloon](/The_Stardrop_Saloon "The Stardrop Saloon")'s rotating stock. One Vegetable Medley may be received from opening a [Mystery Box](/Mystery_Box "Mystery Box"). The [Statue Of Endless Fortune](/Statue_Of_Endless_Fortune "Statue Of Endless Fortune") produces one Vegetable Medley per year on [Lewis](/Lewis "Lewis")' birthday, [Spring 7](/Spring "Spring").

## Gifting

| Villager Reactions | |
| --- | --- |
| Love | [Jodi Icon.png](/Jodi "Jodi") [Jodi](/Jodi "Jodi") • [Leah Icon.png](/Leah "Leah") [Leah](/Leah "Leah") • [Lewis Icon.png](/Lewis "Lewis") [Lewis](/Lewis "Lewis") |
| Like | [Abigail Icon.png](/Abigail "Abigail") [Abigail](/Abigail "Abigail") • [Alex Icon.png](/Alex "Alex") [Alex](/Alex "Alex") • [Caroline Icon.png](/Caroline "Caroline") [Caroline](/Caroline "Caroline") • [Clint Icon.png](/Clint "Clint") [Clint](/Clint "Clint") • [Demetrius Icon.png](/Demetrius "Demetrius") [Demetrius](/Demetrius "Demetrius") • [Dwarf Icon.png](/Dwarf "Dwarf") [Dwarf](/Dwarf "Dwarf") • [Elliott Icon.png](/Elliott "Elliott") [Elliott](/Elliott "Elliott") • [Emily Icon.png](/Emily "Emily") [Emily](/Emily "Emily") • [Evelyn Icon.png](/Evelyn "Evelyn") [Evelyn](/Evelyn "Evelyn") • [George Icon.png](/George "George") [George](/George "George") • [Gus Icon.png](/Gus "Gus") [Gus](/Gus "Gus") • [Haley Icon.png](/Haley "Haley") [Haley](/Haley "Haley") • [Harvey Icon.png](/Harvey "Harvey") [Harvey](/Harvey "Harvey") • [Jas Icon.png](/Jas "Jas") [Jas](/Jas "Jas") • [Kent Icon.png](/Kent "Kent") [Kent](/Kent "Kent") • [Linus Icon.png](/Linus "Linus") [Linus](/Linus "Linus") • [Marnie Icon.png](/Marnie "Marnie") [Marnie](/Marnie "Marnie") • [Maru Icon.png](/Maru "Maru") [Maru](/Maru "Maru") • [Pam Icon.png](/Pam "Pam") [Pam](/Pam "Pam") • [Penny Icon.png](/Penny "Penny") [Penny](/Penny "Penny") • [Pierre Icon.png](/Pierre "Pierre") [Pierre](/Pierre "Pierre") • [Robin Icon.png](/Robin "Robin") [Robin](/Robin "Robin") • [Sam Icon.png](/Sam "Sam") [Sam](/Sam "Sam") • [Sandy Icon.png](/Sandy "Sandy") [Sandy](/Sandy "Sandy") • [Sebastian Icon.png](/Sebastian "Sebastian") [Sebastian](/Sebastian "Sebastian") • [Shane Icon.png](/Shane "Shane") [Shane](/Shane "Shane") • [Vincent Icon.png](/Vincent "Vincent") [Vincent](/Vincent "Vincent") • [Wizard Icon.png](/Wizard "Wizard") [Wizard](/Wizard "Wizard") |
| Dislike | [Krobus Icon.png](/Krobus "Krobus") [Krobus](/Krobus "Krobus") • [Leo Icon.png](/Leo "Leo") [Leo](/Leo "Leo") • [Willy Icon.png](/Willy "Willy") [Willy](/Willy "Willy") |

## Bundles

Vegetable Medley is not used in any [bundles](/Bundles "Bundles").

## Recipes

Vegetable Medley is not used in any recipes.

## Tailoring

Vegetable Medley is used in the spool of the [Sewing Machine](/2_Willow_Lane#Sewing_Machine "2 Willow Lane") with [Cloth](/Cloth "Cloth") in the feed to create a ![Shirt017.png](/mediawiki/images/thumb/d/d2/Shirt017.png/24px-Shirt017.png) [Mayoral Suspenders](/Tailoring "Tailoring"). It is a green dye when used in the spool of the Sewing Machine with a dyeable clothing item in the feed. It can be placed in the green dye pot at Emily's and Haley's house for use in [dyeing](/Dyeing "Dyeing").

## Quests

Vegetable Medley is not used in any [quests](/Quests "Quests").

## History

* [1.4](/Version_History#1.4 "Version History"): Can now be used in [Tailoring](/Tailoring "Tailoring").
* [1.5](/Version_History#1.5 "Version History"): Can now be prepared using a [Cookout Kit](/Cookout_Kit "Cookout Kit").

| Recipes | |
| --- | --- |
| [Cooking](/Cooking "Cooking") | [Algae Soup](/Algae_Soup "Algae Soup") • [Artichoke Dip](/Artichoke_Dip "Artichoke Dip") • [Autumn's Bounty](/Autumn%27s_Bounty "Autumn's Bounty") • [Baked Fish](/Baked_Fish "Baked Fish") • [Banana Pudding](/Banana_Pudding "Banana Pudding") • [Bean Hotpot](/Bean_Hotpot "Bean Hotpot") • [Blackberry Cobbler](/Blackberry_Cobbler "Blackberry Cobbler") • [Blueberry Tart](/Blueberry_Tart "Blueberry Tart") • [Bread](/Bread "Bread") • [Bruschetta](/Bruschetta "Bruschetta") • [Carp Surprise](/Carp_Surprise "Carp Surprise") • [Cheese Cauliflower](/Cheese_Cauliflower "Cheese Cauliflower") • [Chocolate Cake](/Chocolate_Cake "Chocolate Cake") • [Chowder](/Chowder "Chowder") • [Coleslaw](/Coleslaw "Coleslaw") • [Complete Breakfast](/Complete_Breakfast "Complete Breakfast") • [Cookie](/Cookie "Cookie") • [Crab Cakes](/Crab_Cakes "Crab Cakes") • [Cranberry Candy](/Cranberry_Candy "Cranberry Candy") • [Cranberry Sauce](/Cranberry_Sauce "Cranberry Sauce") • [Crispy Bass](/Crispy_Bass "Crispy Bass") • [Dish O' The Sea](/Dish_O%27_The_Sea "Dish O' The Sea") • [Eggplant Parmesan](/Eggplant_Parmesan "Eggplant Parmesan") • [Escargot](/Escargot "Escargot") • [Farmer's Lunch](/Farmer%27s_Lunch "Farmer's Lunch") • [Fiddlehead Risotto](/Fiddlehead_Risotto "Fiddlehead Risotto") • [Fish Stew](/Fish_Stew "Fish Stew") • [Fish Taco](/Fish_Taco "Fish Taco") • [Fried Calamari](/Fried_Calamari "Fried Calamari") • [Fried Eel](/Fried_Eel "Fried Eel") • [Fried Egg](/Fried_Egg "Fried Egg") • [Fried Mushroom](/Fried_Mushroom "Fried Mushroom") • [Fruit Salad](/Fruit_Salad "Fruit Salad") • [Glazed Yams](/Glazed_Yams "Glazed Yams") • [Ginger Ale](/Ginger_Ale "Ginger Ale") • [Hashbrowns](/Hashbrowns "Hashbrowns") • [Ice Cream](/Ice_Cream "Ice Cream") • [Lobster Bisque](/Lobster_Bisque "Lobster Bisque") • [Lucky Lunch](/Lucky_Lunch "Lucky Lunch") • [Maki Roll](/Maki_Roll "Maki Roll") • [Mango Sticky Rice](/Mango_Sticky_Rice "Mango Sticky Rice") • [Maple Bar](/Maple_Bar "Maple Bar") • [Miner's Treat](/Miner%27s_Treat "Miner's Treat") • [Moss Soup](/Moss_Soup "Moss Soup") • [Omelet](/Omelet "Omelet") • [Pale Broth](/Pale_Broth "Pale Broth") • [Pancakes](/Pancakes "Pancakes") • [Parsnip Soup](/Parsnip_Soup "Parsnip Soup") • [Pepper Poppers](/Pepper_Poppers "Pepper Poppers") • [Pink Cake](/Pink_Cake "Pink Cake") • [Pizza](/Pizza "Pizza") • [Plum Pudding](/Plum_Pudding "Plum Pudding") • [Poi](/Poi "Poi") • [Poppyseed Muffin](/Poppyseed_Muffin "Poppyseed Muffin") • [Pumpkin Pie](/Pumpkin_Pie "Pumpkin Pie") • [Pumpkin Soup](/Pumpkin_Soup "Pumpkin Soup") • [Radish Salad](/Radish_Salad "Radish Salad") • [Red Plate](/Red_Plate "Red Plate") • [Rhubarb Pie](/Rhubarb_Pie "Rhubarb Pie") • [Rice Pudding](/Rice_Pudding "Rice Pudding") • [Roasted Hazelnuts](/Roasted_Hazelnuts "Roasted Hazelnuts") • [Roots Platter](/Roots_Platter "Roots Platter") • [Salad](/Salad "Salad") • [Salmon Dinner](/Salmon_Dinner "Salmon Dinner") • [Sashimi](/Sashimi "Sashimi") • [Seafoam Pudding](/Seafoam_Pudding "Seafoam Pudding") • [Shrimp Cocktail](/Shrimp_Cocktail "Shrimp Cocktail") • [Spaghetti](/Spaghetti "Spaghetti") • [Spicy Eel](/Spicy_Eel "Spicy Eel") • [Squid Ink Ravioli](/Squid_Ink_Ravioli "Squid Ink Ravioli") • [Stir Fry](/Stir_Fry "Stir Fry") • [Strange Bun](/Strange_Bun "Strange Bun") • [Stuffing](/Stuffing "Stuffing") • [Super Meal](/Super_Meal "Super Meal") • [Survival Burger](/Survival_Burger "Survival Burger") • [Tom Kha Soup](/Tom_Kha_Soup "Tom Kha Soup") • [Tortilla](/Tortilla "Tortilla") • [Triple Shot Espresso](/Triple_Shot_Espresso "Triple Shot Espresso") • [Tropical Curry](/Tropical_Curry "Tropical Curry") • [Trout Soup](/Trout_Soup "Trout Soup") • Vegetable Medley |
| [Crafting](/Crafting "Crafting") | [Bug Steak](/Bug_Steak "Bug Steak") • [Field Snack](/Field_Snack "Field Snack") • [Life Elixir](/Life_Elixir "Life Elixir") • [Oil of Garlic](/Oil_of_Garlic "Oil of Garlic") |