# False Magma Cap

|  |  |
| --- | --- |
| False Magma Cap | |
| [False Magma Cap Anim.gif](/File:False_Magma_Cap_Anim.gif) | |
| Information | |
| Spawns In: | [Volcano Dungeon](/Volcano_Dungeon "Volcano Dungeon") |
| Floors: | All |
| Killable: | Yes |
| Base HP: | 290 |
| Base Damage: | 15 |
| Base Def: | 3 |
| Speed: | 3 |
| XP: | 14 |
| Variations: | None |
| Drops: | Cinder Shard.png [Cinder Shard](/Cinder_Shard "Cinder Shard") (50%)Cinder Shard.png [Cinder Shard](/Cinder_Shard "Cinder Shard") (20%)Magma Cap.png [Magma Cap](/Magma_Cap "Magma Cap") (99%) If reached bottom of Mines: Diamond.png [Diamond](/Diamond "Diamond") (0.05%)Prismatic Shard.png [Prismatic Shard](/Prismatic_Shard "Prismatic Shard") (0.05%) |

**False Magma Caps** are an [enemy](/Monsters "Monsters") found in the [Volcano Dungeon](/Volcano_Dungeon "Volcano Dungeon").

## Behavior

False Magma Caps disguise themselves as stationary [Magma Caps](/Magma_Cap "Magma Cap"), sometimes surprising the player. Their behavior is similar to [Rock Crabs](/Rock_Crab "Rock Crab") and [Lava Crabs](/Lava_Crab "Lava Crab"). However, they are not invulnerable while immobile.

## Strategy

Although False Magma Caps only move around once the player draws near, they can be differentiated at a distance from normal [Magma Caps](/Magma_Cap "Magma Cap") by moving the cursor over them. If the green "+" symbol ([![Energy.png](/mediawiki/images/thumb/a/a9/Energy.png/25px-Energy.png)](/File:Energy.png)) indicating a [forageable item](/Foraging "Foraging") does not appear, then it is a False Magma Cap.

## History

* [1.5](/Version_History#1.5 "Version History"): Introduced.

| [Monsters](/Monsters "Monsters") | |
| --- | --- |
| [Mines](/The_Mines "The Mines") | [Bats](/Bats "Bats") • [Bug](/Bug "Bug") • [Cave Fly](/Cave_Fly "Cave Fly") • [Duggy](/Duggy "Duggy") • [Dust Sprite](/Dust_Sprite "Dust Sprite") • [Ghost](/Ghost "Ghost") • [Grub](/Grub "Grub") • [Lava Crab](/Lava_Crab "Lava Crab") • [Metal Head](/Metal_Head "Metal Head") • [Rock Crab](/Rock_Crab "Rock Crab") • [Shadow Brute](/Shadow_Brute "Shadow Brute") • [Shadow Shaman](/Shadow_Shaman "Shadow Shaman") • [Skeleton](/Skeleton "Skeleton") • [Slimes](/Slimes "Slimes") • [Squid Kid](/Squid_Kid "Squid Kid") • [Stone Golem](/Stone_Golem "Stone Golem") |
| [Dangerous Mines](/The_Mines#Shrine_of_Challenge "The Mines") | [Bat (dangerous)](/Bats "Bats") • [Blue Squid](/Blue_Squid "Blue Squid") • [Bug (dangerous)](/Bug_(dangerous) "Bug (dangerous)") • [Carbon Ghost](/Carbon_Ghost "Carbon Ghost") • [Cave Fly (dangerous)](/Cave_Fly_(dangerous) "Cave Fly (dangerous)") • [Duggy (dangerous)](/Duggy_(dangerous) "Duggy (dangerous)") • [Dust Sprite (dangerous)](/Dust_Sprite_(dangerous) "Dust Sprite (dangerous)") • [Frost Bat (dangerous)](/Bats "Bats") • [Grub (dangerous)](/Grub_(dangerous) "Grub (dangerous)") • [Haunted Skull (dangerous)](/Haunted_Skull_(dangerous) "Haunted Skull (dangerous)") • [Lava Crab (dangerous)](/Lava_Crab_(dangerous) "Lava Crab (dangerous)") • [Metal Head (dangerous)](/Metal_Head_(dangerous) "Metal Head (dangerous)") • [Putrid Ghost](/Putrid_Ghost "Putrid Ghost") • [Rock Crab (dangerous)](/Rock_Crab_(dangerous) "Rock Crab (dangerous)") • [Shadow Brute (dangerous)](/Shadow_Brute_(dangerous) "Shadow Brute (dangerous)") • [Shadow Shaman (dangerous)](/Shadow_Shaman_(dangerous) "Shadow Shaman (dangerous)") • [Shadow Sniper](/Shadow_Sniper "Shadow Sniper") • [Skeleton (dangerous)](/Skeleton_(dangerous) "Skeleton (dangerous)") • [Skeleton Mage](/Skeleton_Mage "Skeleton Mage") • [Slimes (dangerous)](/Slimes "Slimes") • [Spider](/Spider "Spider") • [Squid Kid (dangerous)](/Squid_Kid_(dangerous) "Squid Kid (dangerous)") • [Stick Bug](/Stick_Bug "Stick Bug") • [Stone Golem (dangerous)](/Stone_Golem_(dangerous) "Stone Golem (dangerous)") |
| [Quarry Mine](/Quarry_Mine "Quarry Mine") | [Copper Slime](/Slimes "Slimes") • [Haunted Skull](/Haunted_Skull "Haunted Skull") • [Iron Slime](/Slimes "Slimes") |
| [Skull Cavern](/Skull_Cavern "Skull Cavern") | [Armored Bug](/Armored_Bug "Armored Bug") • [Big Slime](/Slimes#Big_Slimes "Slimes") • [Carbon Ghost](/Carbon_Ghost "Carbon Ghost") • [Iridium Bat](/Bats "Bats") • [Iridium Crab](/Iridium_Crab "Iridium Crab") • [Lava Bat](/Bats "Bats") • [Mummy](/Mummy "Mummy") • [Pepper Rex](/Pepper_Rex "Pepper Rex") • [Purple Slime](/Slimes "Slimes") • [Serpent](/Serpent "Serpent") |
| Dangerous Skull Cavern | [Armored Bug (dangerous)](/Armored_Bug_(dangerous) "Armored Bug (dangerous)") • [Mummy (dangerous)](/Mummy_(dangerous) "Mummy (dangerous)") • [Royal Serpent](/Royal_Serpent "Royal Serpent") • [Slime (dangerous)](/Slimes "Slimes") |
| [Bug Lair](/Mutant_Bug_Lair "Mutant Bug Lair") | [Mutant Fly](/Mutant_Fly "Mutant Fly") • [Mutant Grub](/Mutant_Grub "Mutant Grub") |
| [The Farm](/The_Farm "The Farm") | [Iridium Golem](/Iridium_Golem "Iridium Golem") • [Truffle Crab](/Truffle_Crab "Truffle Crab") • [Wilderness Golem](/Wilderness_Golem "Wilderness Golem") |
| [Volcano Dungeon](/Volcano_Dungeon "Volcano Dungeon") | [Dwarvish Sentry](/Dwarvish_Sentry "Dwarvish Sentry") • False Magma Cap • [Hot Head](/Hot_Head "Hot Head") • [Lava Lurk](/Lava_Lurk "Lava Lurk") • [Magma Duggy](/Magma_Duggy "Magma Duggy") • [Magma Sparker](/Magma_Sparker "Magma Sparker") • [Magma Sprite](/Magma_Sprite "Magma Sprite") • [Tiger Slime](/Slimes "Slimes") |