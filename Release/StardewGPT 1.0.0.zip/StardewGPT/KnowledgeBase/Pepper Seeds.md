# Pepper Seeds

|  |  |
| --- | --- |
| Pepper Seeds | |
| [Pepper Seeds.png](/File:Pepper_Seeds.png) | |
| Plant these in the summer. Takes 5 days to mature, and continues to produce after first harvest. | |
| Information | |
| Crop: | Hot Pepper.png [Hot Pepper](/Hot_Pepper "Hot Pepper") |
| Growth Time: | 5 days |
| Season: | Summer.png [Summer](/Summer "Summer") |
| Sell Price: | data-sort-value="20">Gold.png20g |
| Purchase Prices | |
| Pierre Icon.png [General Store](/Pierre%27s_General_Store "Pierre's General Store"): | data-sort-value="40">Gold.png40g |
| Morris Icon.png [JojaMart](/JojaMart "JojaMart"): | data-sort-value="50">Gold.png50g |
| Traveling Cart Icon.png [Traveling Cart](/Traveling_Cart "Traveling Cart"): | data-sort-value="20"Gold.png100–1,000g |
| [Night Market](/Night_Market "Night Market") (Winter 16): | data-sort-value="40">Gold.png40g |

**Pepper Seeds** are a type of seed. Mature plants yield [Hot Peppers](/Hot_Pepper "Hot Pepper").

They can be purchased at [Pierre's General Store](/Pierre%27s_General_Store "Pierre's General Store"), at [JojaMart](/JojaMart "JojaMart"), from the Magic Shop Boat at the [Night Market](/Night_Market "Night Market") on Winter 16, and occasionally from the [Traveling Cart](/Traveling_Cart "Traveling Cart"). They can also be obtained by using the [Seed Maker](/Seed_Maker "Seed Maker"), as well as having a chance of being planted when using [Mixed Seeds](/Mixed_Seeds "Mixed Seeds"). Five to twenty Pepper Seeds may occasionally be found in [treasure rooms](/Skull_Cavern#Treasure_Rooms "Skull Cavern") in the Skull Cavern. Eight to twenty Pepper Seeds may be received from opening a [Mystery Box](/Mystery_Box "Mystery Box") or [Golden Mystery Box](/Golden_Mystery_Box "Golden Mystery Box").

## Stages

When harvested, each Hot Pepper plant gives 1 Hot Pepper every 3 days, with a 3% chance for more Hot Peppers.

| Stage 1 | Stage 2 | Stage 3 | Stage 4 | Stage 5 | Harvest | After-Harvest |
| --- | --- | --- | --- | --- | --- | --- |
| Hot Pepper Stage 1.png | Hot Pepper Stage 2.png | Hot Pepper Stage 3.png | Hot Pepper Stage 4.png | Hot Pepper Stage 4b.png | Hot Pepper Stage 5.png | Hot Pepper Stage 6.png |
| 1 Day | 1 Day | 1 Day | 1 Day | 1 Day | Total: 5 Days | Regrowth: 3 Days |

## Gifting

| Villager Reactions | |
| --- | --- |
| Dislike | [Abigail Icon.png](/Abigail "Abigail") [Abigail](/Abigail "Abigail") • [Alex Icon.png](/Alex "Alex") [Alex](/Alex "Alex") • [Caroline Icon.png](/Caroline "Caroline") [Caroline](/Caroline "Caroline") • [Clint Icon.png](/Clint "Clint") [Clint](/Clint "Clint") • [Demetrius Icon.png](/Demetrius "Demetrius") [Demetrius](/Demetrius "Demetrius") • [Dwarf Icon.png](/Dwarf "Dwarf") [Dwarf](/Dwarf "Dwarf") • [Elliott Icon.png](/Elliott "Elliott") [Elliott](/Elliott "Elliott") • [Emily Icon.png](/Emily "Emily") [Emily](/Emily "Emily") • [Evelyn Icon.png](/Evelyn "Evelyn") [Evelyn](/Evelyn "Evelyn") • [George Icon.png](/George "George") [George](/George "George") • [Gus Icon.png](/Gus "Gus") [Gus](/Gus "Gus") • [Haley Icon.png](/Haley "Haley") [Haley](/Haley "Haley") • [Harvey Icon.png](/Harvey "Harvey") [Harvey](/Harvey "Harvey") • [Jas Icon.png](/Jas "Jas") [Jas](/Jas "Jas") • [Jodi Icon.png](/Jodi "Jodi") [Jodi](/Jodi "Jodi") • [Kent Icon.png](/Kent "Kent") [Kent](/Kent "Kent") • [Krobus Icon.png](/Krobus "Krobus") [Krobus](/Krobus "Krobus") • [Leah Icon.png](/Leah "Leah") [Leah](/Leah "Leah") • [Leo Icon.png](/Leo "Leo") [Leo](/Leo "Leo") • [Lewis Icon.png](/Lewis "Lewis") [Lewis](/Lewis "Lewis") • [Linus Icon.png](/Linus "Linus") [Linus](/Linus "Linus") • [Marnie Icon.png](/Marnie "Marnie") [Marnie](/Marnie "Marnie") • [Maru Icon.png](/Maru "Maru") [Maru](/Maru "Maru") • [Pam Icon.png](/Pam "Pam") [Pam](/Pam "Pam") • [Penny Icon.png](/Penny "Penny") [Penny](/Penny "Penny") • [Pierre Icon.png](/Pierre "Pierre") [Pierre](/Pierre "Pierre") • [Robin Icon.png](/Robin "Robin") [Robin](/Robin "Robin") • [Sam Icon.png](/Sam "Sam") [Sam](/Sam "Sam") • [Sandy Icon.png](/Sandy "Sandy") [Sandy](/Sandy "Sandy") • [Sebastian Icon.png](/Sebastian "Sebastian") [Sebastian](/Sebastian "Sebastian") • [Shane Icon.png](/Shane "Shane") [Shane](/Shane "Shane") • [Vincent Icon.png](/Vincent "Vincent") [Vincent](/Vincent "Vincent") • [Willy Icon.png](/Willy "Willy") [Willy](/Willy "Willy") • [Wizard Icon.png](/Wizard "Wizard") [Wizard](/Wizard "Wizard") |

| Seeds, Starters, and Saplings | |
| --- | --- |
| Spring | [Apricot Sapling](/Apricot_Sapling "Apricot Sapling") • [Bean Starter](/Bean_Starter "Bean Starter") • [Carrot Seeds](/Carrot_Seeds "Carrot Seeds") • [Cauliflower Seeds](/Cauliflower_Seeds "Cauliflower Seeds") • [Cherry Sapling](/Cherry_Sapling "Cherry Sapling") • [Coffee Beans](/Coffee_Bean "Coffee Bean") • [Garlic Seeds](/Garlic_Seeds "Garlic Seeds") • [Jazz Seeds](/Jazz_Seeds "Jazz Seeds") • [Kale Seeds](/Kale_Seeds "Kale Seeds") • [Parsnip Seeds](/Parsnip_Seeds "Parsnip Seeds") • [Potato Seeds](/Potato_Seeds "Potato Seeds") • [Rice Shoot](/Rice_Shoot "Rice Shoot") • [Rhubarb Seeds](/Rhubarb_Seeds "Rhubarb Seeds") • [Spring Seeds](/Spring_Seeds "Spring Seeds") • [Strawberry Seeds](/Strawberry_Seeds "Strawberry Seeds") • [Tulip Bulb](/Tulip_Bulb "Tulip Bulb") |
| Summer | [Blueberry Seeds](/Blueberry_Seeds "Blueberry Seeds") • [Coffee Beans](/Coffee_Bean "Coffee Bean") • [Corn Seeds](/Corn_Seeds "Corn Seeds") • [Hops Starter](/Hops_Starter "Hops Starter") • [Melon Seeds](/Melon_Seeds "Melon Seeds") • [Orange Sapling](/Orange_Sapling "Orange Sapling") • [Peach Sapling](/Peach_Sapling "Peach Sapling") • Pepper Seeds • [Poppy Seeds](/Poppy_Seeds "Poppy Seeds") • [Radish Seeds](/Radish_Seeds "Radish Seeds") • [Red Cabbage Seeds](/Red_Cabbage_Seeds "Red Cabbage Seeds") • [Spangle Seeds](/Spangle_Seeds "Spangle Seeds") • [Summer Seeds](/Summer_Seeds "Summer Seeds") • [Summer Squash Seeds](/Summer_Squash_Seeds "Summer Squash Seeds") • [Sunflower Seeds](/Sunflower_Seeds "Sunflower Seeds") • [Starfruit Seeds](/Starfruit_Seeds "Starfruit Seeds") • [Tomato Seeds](/Tomato_Seeds "Tomato Seeds") • [Wheat Seeds](/Wheat_Seeds "Wheat Seeds") |
| Fall | [Amaranth Seeds](/Amaranth_Seeds "Amaranth Seeds") • [Apple Sapling](/Apple_Sapling "Apple Sapling") • [Artichoke Seeds](/Artichoke_Seeds "Artichoke Seeds") • [Beet Seeds](/Beet_Seeds "Beet Seeds") • [Bok Choy Seeds](/Bok_Choy_Seeds "Bok Choy Seeds") • [Broccoli Seeds](/Broccoli_Seeds "Broccoli Seeds") • [Corn Seeds](/Corn_Seeds "Corn Seeds") • [Cranberry Seeds](/Cranberry_Seeds "Cranberry Seeds") • [Eggplant Seeds](/Eggplant_Seeds "Eggplant Seeds") • [Fairy Seeds](/Fairy_Seeds "Fairy Seeds") • [Fall Seeds](/Fall_Seeds "Fall Seeds") • [Grape Starter](/Grape_Starter "Grape Starter") • [Pomegranate Sapling](/Pomegranate_Sapling "Pomegranate Sapling") • [Pumpkin Seeds](/Pumpkin_Seeds "Pumpkin Seeds") • [Rare Seed](/Rare_Seed "Rare Seed") • [Sunflower Seeds](/Sunflower_Seeds "Sunflower Seeds") • [Wheat Seeds](/Wheat_Seeds "Wheat Seeds") • [Yam Seeds](/Yam_Seeds "Yam Seeds") |
| Winter | [Powdermelon Seeds](/Powdermelon_Seeds "Powdermelon Seeds") • [Winter Seeds](/Winter_Seeds "Winter Seeds") |
| Other | [Acorn](/Acorn "Acorn") • [Ancient Seeds](/Ancient_Seeds "Ancient Seeds") • [Banana Sapling](/Banana_Sapling "Banana Sapling") • [Blue Grass Starter](/Blue_Grass_Starter "Blue Grass Starter") • [Cactus Seeds](/Cactus_Seeds "Cactus Seeds") • [Fiber Seeds](/Fiber_Seeds "Fiber Seeds") • [Grass Starter](/Grass_Starter "Grass Starter") • [Mahogany Seed](/Mahogany_Seed "Mahogany Seed") • [Mango Sapling](/Mango_Sapling "Mango Sapling") • [Maple Seed](/Maple_Seed "Maple Seed") • [Mixed Flower Seeds](/Mixed_Flower_Seeds "Mixed Flower Seeds") • [Mixed Seeds](/Mixed_Seeds "Mixed Seeds") • [Mossy Seed](/Mossy_Seed "Mossy Seed") • [Mushroom Tree Seed](/Mushroom_Tree_Seed "Mushroom Tree Seed") • [Mystic Tree Seed](/Mystic_Tree_Seed "Mystic Tree Seed") • [Pineapple Seeds](/Pineapple_Seeds "Pineapple Seeds") • [Qi Bean](/Qi_Bean "Qi Bean") • [Tea Sapling](/Tea_Sapling "Tea Sapling") • [Pine Cone](/Pine_Cone "Pine Cone") • [Taro Tuber](/Taro_Tuber "Taro Tuber") |