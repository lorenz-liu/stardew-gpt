# Halibut

|  |  |
| --- | --- |
| Halibut | |
| [Halibut.png](/File:Halibut.png) | |
| A flat fish that lives on the ocean floor. | |
| Information | |
| Location | [Ocean](/The_Beach "The Beach") |
| Time | 6am – 11am 7pm – 2am |
| Season | Spring.png [Spring](/Spring "Spring") • Summer.png [Summer](/Summer "Summer") • Winter.png [Winter](/Winter "Winter") |
| Weather | [Any](/Weather "Weather") |
| Difficulty | 50 |
| Behavior | [Sinker](/Fish#Behavior "Fish") |
| Size (inches) | 10–34 |
| Fishing XP | 19   Silver Quality.png 22   Gold Quality.png 25   Iridium Quality.png 31 |
| [Energy](/Energy "Energy") / [Health](/Health "Health") | |  |  |  |  | | --- | --- | --- | --- | | Energy.png | 25 | Health.png | 11 | | Energy.png  Silver Quality Icon.png | 35 | Health.png  Silver Quality Icon.png | 15 | | Energy.png  Gold Quality Icon.png | 45 | Health.png  Gold Quality Icon.png | 20 | | Energy.png  Iridium Quality Icon.png | 65 | Health.png  Iridium Quality Icon.png | 29 | |
| |  |  |  | | --- | --- | --- | | Sell Prices | | | | Base | Fisher.png [Fisher](/Skills#Fishing "Skills") *(+25%)* | Angler Icon.png [Angler](/Skills#Fishing "Skills") *(+50%)* | | |  |  | | --- | --- | | Halibut.png | 80g | | Halibut.png  Silver Quality Icon.png | 100g | | Halibut.png  Gold Quality Icon.png | 120g | | Halibut.png  Iridium Quality Icon.png | 160g | | |  |  | | --- | --- | | Halibut.png | 100g | | Halibut.png  Silver Quality Icon.png | 125g | | Halibut.png  Gold Quality Icon.png | 150g | | Halibut.png  Iridium Quality Icon.png | 200g | | |  |  | | --- | --- | | Halibut.png | 120g | | Halibut.png  Silver Quality Icon.png | 150g | | Halibut.png  Gold Quality Icon.png | 180g | | Halibut.png  Iridium Quality Icon.png | 240g | | | |
| |  |  |  | | --- | --- | --- | | Artisan Sell Prices | | | | Roe | Aged Roe | Artisan.png Aged Roe *(+40%)* | | |  |  | | --- | --- | | Light Gray Roe.png | 70g | | |  |  | | --- | --- | | Light Gray Aged Roe.png | 140g | | |  |  | | --- | --- | | Light Gray Aged Roe.png | 196g | | | |

The **Halibut** is a [fish](/Fish "Fish") that can be caught in the ocean at [The Beach](/The_Beach "The Beach") or on the [Beach Farm](/Farm_Maps#Beach "Farm Maps") during [Spring](/Spring "Spring"), [Summer](/Summer "Summer"), and [Winter](/Winter "Winter"). It may also randomly appear in [Krobus](/Krobus "Krobus")' shop on [Wednesdays](/Days_of_the_Week#Wednesday "Days of the Week") for data-sort-value="200">![Gold.png](/mediawiki/images/thumb/1/10/Gold.png/18px-Gold.png)200g, or at the [Traveling Cart](/Traveling_Cart "Traveling Cart") for data-sort-value="80"![Gold.png](/mediawiki/images/thumb/1/10/Gold.png/18px-Gold.png)240–1,000g.

Halibut can be caught regardless of time of day or season using [Magic Bait](/Magic_Bait "Magic Bait").

## Map

The Halibut can be found in the ocean.

![Maplocation.png](/mediawiki/images/thumb/5/5c/Maplocation.png/20px-Maplocation.png)

![Map.png](/mediawiki/images/4/43/Map.png)

## Gifting

| Villager Reactions | |
| --- | --- |
| Neutral | [Demetrius Icon.png](/Demetrius "Demetrius") [Demetrius](/Demetrius "Demetrius") • [Elliott Icon.png](/Elliott "Elliott") [Elliott](/Elliott "Elliott") • [Leo Icon.png](/Leo "Leo") [Leo](/Leo "Leo") • [Linus Icon.png](/Linus "Linus") [Linus](/Linus "Linus") • [Pam Icon.png](/Pam "Pam") [Pam](/Pam "Pam") • [Sebastian Icon.png](/Sebastian "Sebastian") [Sebastian](/Sebastian "Sebastian") • [Willy Icon.png](/Willy "Willy") [Willy](/Willy "Willy") |
| Dislike | [Abigail Icon.png](/Abigail "Abigail") [Abigail](/Abigail "Abigail") • [Alex Icon.png](/Alex "Alex") [Alex](/Alex "Alex") • [Caroline Icon.png](/Caroline "Caroline") [Caroline](/Caroline "Caroline") • [Clint Icon.png](/Clint "Clint") [Clint](/Clint "Clint") • [Dwarf Icon.png](/Dwarf "Dwarf") [Dwarf](/Dwarf "Dwarf") • [Emily Icon.png](/Emily "Emily") [Emily](/Emily "Emily") • [George Icon.png](/George "George") [George](/George "George") • [Gus Icon.png](/Gus "Gus") [Gus](/Gus "Gus") • [Harvey Icon.png](/Harvey "Harvey") [Harvey](/Harvey "Harvey") • [Jas Icon.png](/Jas "Jas") [Jas](/Jas "Jas") • [Jodi Icon.png](/Jodi "Jodi") [Jodi](/Jodi "Jodi") • [Kent Icon.png](/Kent "Kent") [Kent](/Kent "Kent") • [Krobus Icon.png](/Krobus "Krobus") [Krobus](/Krobus "Krobus") • [Leah Icon.png](/Leah "Leah") [Leah](/Leah "Leah") • [Lewis Icon.png](/Lewis "Lewis") [Lewis](/Lewis "Lewis") • [Marnie Icon.png](/Marnie "Marnie") [Marnie](/Marnie "Marnie") • [Maru Icon.png](/Maru "Maru") [Maru](/Maru "Maru") • [Penny Icon.png](/Penny "Penny") [Penny](/Penny "Penny") • [Robin Icon.png](/Robin "Robin") [Robin](/Robin "Robin") • [Sam Icon.png](/Sam "Sam") [Sam](/Sam "Sam") • [Sandy Icon.png](/Sandy "Sandy") [Sandy](/Sandy "Sandy") • [Shane Icon.png](/Shane "Shane") [Shane](/Shane "Shane") • [Vincent Icon.png](/Vincent "Vincent") [Vincent](/Vincent "Vincent") • [Wizard Icon.png](/Wizard "Wizard") [Wizard](/Wizard "Wizard") |
| Hate | [Evelyn Icon.png](/Evelyn "Evelyn") [Evelyn](/Evelyn "Evelyn") • [Haley Icon.png](/Haley "Haley") [Haley](/Haley "Haley") • [Pierre Icon.png](/Pierre "Pierre") [Pierre](/Pierre "Pierre") |

## Bundles

Halibut is not used in any [bundles](/Bundles "Bundles").

## Recipes

| Image | Name | Description | Ingredients | Energy / Health | Recipe Source(s) | Sell Price |
| --- | --- | --- | --- | --- | --- | --- |
| [Maki Roll.png](/File:Maki_Roll.png) | [Maki Roll](/Maki_Roll "Maki Roll") | Fish and rice wrapped in seaweed. | Fish.png Any [Fish](/Fish "Fish") (1)Seaweed.png [Seaweed](/Seaweed "Seaweed") (1)Rice.png [Rice](/Rice "Rice") (1) | Energy.png 100 Health.png 45 | |  |  | | --- | --- | | Cooking Channel.png | [The Queen of Sauce](/The_Queen_of_Sauce "The Queen of Sauce") | | 21 Summer, Year 1 |     Gus Icon.png [Stardrop Saloon](/The_Stardrop_Saloon#Menu "The Stardrop Saloon") for data-sort-value="300">Gold.png300g | data-sort-value="220">Gold.png220g |
| [Quality Fertilizer.png](/File:Quality_Fertilizer.png) | [Quality Fertilizer](/Quality_Fertilizer "Quality Fertilizer") | Improves soil quality, increasing your chance to grow quality crops. Mix into tilled soil. | Sap.png [Sap](/Sap "Sap") (4)Fish.png Any [Fish](/Fish "Fish") (1) | N/A | Farming Skill Icon.png [Farming](/Farming "Farming") Level 9 | data-sort-value="10">Gold.png10g |
| [Sashimi.png](/File:Sashimi.png) | [Sashimi](/Sashimi "Sashimi") | Raw fish sliced into thin pieces. | Fish.png Any [Fish](/Fish "Fish") (1) | Energy.png 75 Health.png 33 | Linus Icon.png [Linus](/Linus "Linus") (Mail - 3+ HeartIconLarge.png) | data-sort-value="75">Gold.png75g |

## Tailoring

Halibut can be used in the spool of the [Sewing Machine](/2_Willow_Lane#Sewing_Machine "2 Willow Lane") to create the dyeable [Sailor Shirt](/Tailoring "Tailoring"). [![Shirt259a.png](/mediawiki/images/thumb/3/36/Shirt259a.png/24px-Shirt259a.png)](/File:Shirt259a.png)

## Fish Pond

Halibut can be placed in a [Fish Pond](/Fish_Pond "Fish Pond"), where they will reproduce every 3 days. The initial pond capacity is 3 fish, but the capacity can be increased to 10 by completing three quests. The only possible output is light gray Halibut [Roe](/Roe "Roe").

**[Quests](/Fish_Pond#Quests "Fish Pond")**

| Pond Capacity | | Quest Item | Fishing XP Granted |
| --- | --- | --- | --- |
| Before Quest | After Quest |
| 3 | 5 | 3 [Driftwood](/Driftwood "Driftwood"), 1 [Frozen Geode](/Frozen_Geode "Frozen Geode"), or 1-2 [Seaweed](/Seaweed "Seaweed") | 35 |
| 5 | 7 | 2 [Clams](/Clam "Clam") or 2 [Coral](/Coral "Coral") | 35 |
| 7 | 10 | 2 [Aquamarine](/Aquamarine "Aquamarine"), 1 [Mussel](/Mussel "Mussel"), or 2 [Sea Urchins](/Sea_Urchin "Sea Urchin") | 35 |

**[Produce](/Fish_Pond#Produce "Fish Pond")**

| Item(s) Produced | Fishing XP Granted | Population | % of Items | Overall Daily Chance |
| --- | --- | --- | --- | --- |
| Light Gray Roe.png [Roe](/Roe "Roe") (1) | 12 | 1-4 | 70% | 16-33% |
| 5-10 | 100% | 55-95% |
| *Nothing* |  | 1-4 | 30% | 84-67% |
| 5-10 | 0% | 45-5% |

## Quests

* **Aquatic Overpopulation:** [Demetrius](/Demetrius "Demetrius") may request 10 Halibut to be caught in [Spring](/Spring "Spring") at the [Special Orders board](/Quests#List_of_Special_Orders "Quests") outside the [Mayor's Manor](/Mayor%27s_Manor "Mayor's Manor") for a reward of gold equivalent to selling the fish and the [Farm Computer](/Farm_Computer "Farm Computer") recipe.

## History

* [1.4](/Version_History#1.4 "Version History"): Added iridium quality. Can now be used in [Tailoring](/Tailoring "Tailoring").
* [1.5](/Version_History#1.5 "Version History"): [Special Order](/Quests#List_of_Special_Orders "Quests") quest added.

| [Fish](/Fish "Fish") | |
| --- | --- |
| Legendary | [Angler](/Angler "Angler") • [Crimsonfish](/Crimsonfish "Crimsonfish") • [Glacierfish](/Glacierfish "Glacierfish") • [Glacierfish Jr.](/Glacierfish_Jr. "Glacierfish Jr.") • [Legend](/Legend "Legend") • [Legend II](/Legend_II "Legend II") • [Ms. Angler](/Ms._Angler "Ms. Angler") • [Mutant Carp](/Mutant_Carp "Mutant Carp") • [Radioactive Carp](/Radioactive_Carp "Radioactive Carp") • [Son of Crimsonfish](/Son_of_Crimsonfish "Son of Crimsonfish") |
| [The Beach](/The_Beach "The Beach") | [Albacore](/Albacore "Albacore") • [Anchovy](/Anchovy "Anchovy") • [Crimsonfish](/Crimsonfish "Crimsonfish") • [Eel](/Eel "Eel") • [Flounder](/Flounder "Flounder") • Halibut • [Herring](/Herring "Herring") • [Octopus](/Octopus "Octopus") • [Pufferfish](/Pufferfish "Pufferfish") • [Red Mullet](/Red_Mullet "Red Mullet") • [Red Snapper](/Red_Snapper "Red Snapper") • [Sardine](/Sardine "Sardine") • [Sea Cucumber](/Sea_Cucumber "Sea Cucumber") • [Son of Crimsonfish](/Son_of_Crimsonfish "Son of Crimsonfish") • [Squid](/Squid "Squid") • [Super Cucumber](/Super_Cucumber "Super Cucumber") • [Tilapia](/Tilapia "Tilapia") • [Tuna](/Tuna "Tuna") |
| River | [Angler](/Angler "Angler") • [Bream](/Bream "Bream") • [Catfish](/Catfish "Catfish") • [Chub](/Chub "Chub") • [Dorado](/Dorado "Dorado") • [Glacierfish](/Glacierfish "Glacierfish") • [Glacierfish Jr.](/Glacierfish_Jr. "Glacierfish Jr.") • [Goby](/Goby "Goby") • [Lingcod](/Lingcod "Lingcod") • [Ms. Angler](/Ms._Angler "Ms. Angler") • [Perch](/Perch "Perch") • [Pike](/Pike "Pike") • [Rainbow Trout](/Rainbow_Trout "Rainbow Trout") • [Salmon](/Salmon "Salmon") • [Shad](/Shad "Shad") • [Smallmouth Bass](/Smallmouth_Bass "Smallmouth Bass") • [Sunfish](/Sunfish "Sunfish") • [Tiger Trout](/Tiger_Trout "Tiger Trout") • [Walleye](/Walleye "Walleye") |
| [Mountain Lake](/The_Mountain "The Mountain") | [Bullhead](/Bullhead "Bullhead") • [Carp](/Carp "Carp") • [Chub](/Chub "Chub") • [Largemouth Bass](/Largemouth_Bass "Largemouth Bass") • [Legend](/Legend "Legend") • [Legend II](/Legend_II "Legend II") • [Lingcod](/Lingcod "Lingcod") • [Midnight Carp](/Midnight_Carp "Midnight Carp") • [Perch](/Perch "Perch") • [Rainbow Trout](/Rainbow_Trout "Rainbow Trout") • [Sturgeon](/Sturgeon "Sturgeon") • [Walleye](/Walleye "Walleye") |
| [Cindersap Forest Pond](/Cindersap_Forest "Cindersap Forest") | [Midnight Carp](/Midnight_Carp "Midnight Carp") • [Perch](/Perch "Perch") • [Pike](/Pike "Pike") • [Smallmouth Bass](/Smallmouth_Bass "Smallmouth Bass") • [Walleye](/Walleye "Walleye") |
| [Secret Woods](/Secret_Woods "Secret Woods") | [Carp](/Carp "Carp") • [Catfish](/Catfish "Catfish") • [Woodskip](/Woodskip "Woodskip") |
| [Mines](/The_Mines "The Mines") | [Ghostfish](/Ghostfish "Ghostfish") • [Ice Pip](/Ice_Pip "Ice Pip") • [Lava Eel](/Lava_Eel "Lava Eel") • [Stonefish](/Stonefish "Stonefish") |
| [Sewers](/The_Sewers "The Sewers") | [Carp](/Carp "Carp") • [Mutant Carp](/Mutant_Carp "Mutant Carp") • [Radioactive Carp](/Radioactive_Carp "Radioactive Carp") |
| [Desert](/The_Desert "The Desert") | [Sandfish](/Sandfish "Sandfish") • [Scorpion Carp](/Scorpion_Carp "Scorpion Carp") |
| [Mutant Bug Lair](/Mutant_Bug_Lair "Mutant Bug Lair") | [Carp](/Carp "Carp") • [Slimejack](/Slimejack "Slimejack") |
| [Witch's Swamp](/Witch%27s_Swamp "Witch's Swamp") | [Catfish](/Catfish "Catfish") • [Void Salmon](/Void_Salmon "Void Salmon") |
| [Night Market](/Night_Market "Night Market") | [Blobfish](/Blobfish "Blobfish") • [Midnight Squid](/Midnight_Squid "Midnight Squid") • [Octopus](/Octopus "Octopus") • [Sea Cucumber](/Sea_Cucumber "Sea Cucumber") • [Spook Fish](/Spook_Fish "Spook Fish") • [Super Cucumber](/Super_Cucumber "Super Cucumber") |
| [Crab Pot](/Crab_Pot "Crab Pot") | [Clam](/Clam "Clam") • [Cockle](/Cockle "Cockle") • [Crab](/Crab "Crab") • [Crayfish](/Crayfish "Crayfish") • [Lobster](/Lobster "Lobster") • [Mussel](/Mussel "Mussel") • [Oyster](/Oyster "Oyster") • [Periwinkle](/Periwinkle "Periwinkle") • [Shrimp](/Shrimp "Shrimp") • [Snail](/Snail "Snail") |
| [Ginger Island](/Ginger_Island "Ginger Island") | [Blue Discus](/Blue_Discus "Blue Discus") • [Flounder](/Flounder "Flounder") • [Lava Eel](/Lava_Eel "Lava Eel") • [Lionfish](/Lionfish "Lionfish") • [Midnight Carp](/Midnight_Carp "Midnight Carp") • [Octopus](/Octopus "Octopus") • [Pufferfish](/Pufferfish "Pufferfish") • [Stingray](/Stingray "Stingray") • [Super Cucumber](/Super_Cucumber "Super Cucumber") • [Tilapia](/Tilapia "Tilapia") • [Tuna](/Tuna "Tuna") |