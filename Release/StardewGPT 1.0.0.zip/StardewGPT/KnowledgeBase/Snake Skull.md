# Snake Skull

|  |  |
| --- | --- |
| Snake Skull | |
| [Snake Skull.png](/File:Snake_Skull.png) | |
| A preserved skull that once belonged to a snake. | |
| Information | |
| Source | [Ginger Island](/Ginger_Island "Ginger Island") |
| Sell Price | data-sort-value="100">Gold.png100g |

The **Snake Skull** is an item that can be obtained by [fishing](/Fishing "Fishing") or digging [Artifact Spots](/Artifact_Spot "Artifact Spot") in [Ginger Island West](/Ginger_Island#Island_West "Ginger Island"), or by digging Artifact Spots at the [Ginger Island Dig Site](/Ginger_Island#Dig_Site "Ginger Island").

## Donation

The Snake Skull can be donated as part of a [Snake](/Island_Field_Office#Snake "Island Field Office") to the [Island Field Office](/Island_Field_Office "Island Field Office"), which rewards 3 [Golden Walnuts](/Golden_Walnut "Golden Walnut") and a [Mango Sapling](/Mango_Sapling "Mango Sapling") once the specimen is completed.

## Gifting

| Villager Reactions | |
| --- | --- |
| Hate | [Abigail Icon.png](/Abigail "Abigail") [Abigail](/Abigail "Abigail") • [Alex Icon.png](/Alex "Alex") [Alex](/Alex "Alex") • [Caroline Icon.png](/Caroline "Caroline") [Caroline](/Caroline "Caroline") • [Clint Icon.png](/Clint "Clint") [Clint](/Clint "Clint") • [Demetrius Icon.png](/Demetrius "Demetrius") [Demetrius](/Demetrius "Demetrius") • [Dwarf Icon.png](/Dwarf "Dwarf") [Dwarf](/Dwarf "Dwarf") • [Elliott Icon.png](/Elliott "Elliott") [Elliott](/Elliott "Elliott") • [Emily Icon.png](/Emily "Emily") [Emily](/Emily "Emily") • [Evelyn Icon.png](/Evelyn "Evelyn") [Evelyn](/Evelyn "Evelyn") • [George Icon.png](/George "George") [George](/George "George") • [Gus Icon.png](/Gus "Gus") [Gus](/Gus "Gus") • [Haley Icon.png](/Haley "Haley") [Haley](/Haley "Haley") • [Harvey Icon.png](/Harvey "Harvey") [Harvey](/Harvey "Harvey") • [Jas Icon.png](/Jas "Jas") [Jas](/Jas "Jas") • [Jodi Icon.png](/Jodi "Jodi") [Jodi](/Jodi "Jodi") • [Kent Icon.png](/Kent "Kent") [Kent](/Kent "Kent") • [Krobus Icon.png](/Krobus "Krobus") [Krobus](/Krobus "Krobus") • [Leah Icon.png](/Leah "Leah") [Leah](/Leah "Leah") • [Leo Icon.png](/Leo "Leo") [Leo](/Leo "Leo") • [Lewis Icon.png](/Lewis "Lewis") [Lewis](/Lewis "Lewis") • [Linus Icon.png](/Linus "Linus") [Linus](/Linus "Linus") • [Marnie Icon.png](/Marnie "Marnie") [Marnie](/Marnie "Marnie") • [Maru Icon.png](/Maru "Maru") [Maru](/Maru "Maru") • [Pam Icon.png](/Pam "Pam") [Pam](/Pam "Pam") • [Penny Icon.png](/Penny "Penny") [Penny](/Penny "Penny") • [Pierre Icon.png](/Pierre "Pierre") [Pierre](/Pierre "Pierre") • [Robin Icon.png](/Robin "Robin") [Robin](/Robin "Robin") • [Sam Icon.png](/Sam "Sam") [Sam](/Sam "Sam") • [Sandy Icon.png](/Sandy "Sandy") [Sandy](/Sandy "Sandy") • [Sebastian Icon.png](/Sebastian "Sebastian") [Sebastian](/Sebastian "Sebastian") • [Shane Icon.png](/Shane "Shane") [Shane](/Shane "Shane") • [Vincent Icon.png](/Vincent "Vincent") [Vincent](/Vincent "Vincent") • [Willy Icon.png](/Willy "Willy") [Willy](/Willy "Willy") • [Wizard Icon.png](/Wizard "Wizard") [Wizard](/Wizard "Wizard") |

## Bone Mill

The Snake Skull can be turned into [Quality Fertilizer](/Quality_Fertilizer "Quality Fertilizer"), [Speed-Gro](/Speed-Gro "Speed-Gro"), [Deluxe Speed-Gro](/Deluxe_Speed-Gro "Deluxe Speed-Gro") or [Tree Fertilizer](/Tree_Fertilizer "Tree Fertilizer") in the [Bone Mill](/Bone_Mill "Bone Mill").

## Tailoring

Snake Skull is used in the spool of a [Sewing Machine](/2_Willow_Lane#Sewing_Machine "2 Willow Lane") to create the [Skeleton Shirt](/Tailoring "Tailoring"). [![Shirt014.png](/mediawiki/images/thumb/0/0f/Shirt014.png/24px-Shirt014.png)](/File:Shirt014.png) It can be used in [dyeing](/Dyeing "Dyeing"), serving as a yellow dye at the dye pots, located in [Emily](/Emily "Emily")'s and [Haley](/Haley "Haley")'s house, [2 Willow Lane](/2_Willow_Lane "2 Willow Lane").

## Quests

* ["Fragments of the past"](/Quests#Fragments_of_the_past "Quests"): [Gunther](/Gunther "Gunther") may make a request on the [Special Orders board](/Quests#List_of_Special_Orders "Quests") for 100 of any combination of bone items that must be gathered while the quest is active. You have 7 days to complete the quest. The reward is data-sort-value="3500">![Gold.png](/mediawiki/images/thumb/1/10/Gold.png/18px-Gold.png)3,500g and the [Bone Mill](/Bone_Mill "Bone Mill") recipe.

## History

* [1.5](/Version_History#1.5 "Version History"): Introduced.